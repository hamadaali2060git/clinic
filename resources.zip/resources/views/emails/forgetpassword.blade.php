<h1>Forget Password Email</h1>

You can reset password from bellow link:
<a href="{{ url('admin/reset-user-password', $token) }}">Reset Password</a>
