<h1>Forget Password Email</h1>

You can reset password from bellow link:
<a href="{{ url('reset-password-api', $token) }}">Reset Password</a>
